const express = require('express');
const app = express();
const mongoose = require('mongoose');
const Contactus = require('./modal/contactus');
const cors = require('cors');

const corsOptions = {
    origin: 'http://127.0.0.1:5500',
    optionsSuccessStatus: 200,
  }

app.use(cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.listen(3000,(req,res)=>{
    console.log('Server is running on port 3000');
});

app.get('/',(req,res)=>{
    res.send('Hello from server');
})

app.post('/contactus',async(req,res)=>{
    console.log(req.body);
    try{
        const {name,email,message}=req.body;
        if(!name || !email || !message){
            return res.status(422).json({error:"Please fill the contact form properly"});
        }
        const contactus = new Contactus({name,email,message});
        await contactus.save();
        res.status(201).json({message:"Contact us form submitted successfully"});
    }catch(err){
        console.log(err);
    }
})