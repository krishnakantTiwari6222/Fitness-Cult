const mongoose = require('mongoose');
const { Schema } = mongoose;

async function main(){
    await mongoose.connect('mongodb://localhost:27017/contactus')
    console.log('Database connected successfully');
}
main();

const contactusSchema = new Schema({
    name: String,
    email: String,
    message: String
})

const Contactus = mongoose.model('Contactus',contactusSchema);
module.exports = Contactus;